﻿namespace CalculadoraGrafica
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btSumar = new System.Windows.Forms.Button();
            this.btNegar = new System.Windows.Forms.Button();
            this.tbValor1 = new System.Windows.Forms.TextBox();
            this.btCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btSumar
            // 
            this.btSumar.Location = new System.Drawing.Point(52, 60);
            this.btSumar.Name = "btSumar";
            this.btSumar.Size = new System.Drawing.Size(75, 23);
            this.btSumar.TabIndex = 0;
            this.btSumar.Text = "Sumar";
            this.btSumar.UseVisualStyleBackColor = true;
            this.btSumar.Click += new System.EventHandler(this.btSumar_Click);
            // 
            // btNegar
            // 
            this.btNegar.Location = new System.Drawing.Point(52, 31);
            this.btNegar.Name = "btNegar";
            this.btNegar.Size = new System.Drawing.Size(75, 23);
            this.btNegar.TabIndex = 1;
            this.btNegar.Text = "Negar";
            this.btNegar.UseVisualStyleBackColor = true;
            this.btNegar.Click += new System.EventHandler(this.btNegar_Click);
            // 
            // tbValor1
            // 
            this.tbValor1.Location = new System.Drawing.Point(46, 5);
            this.tbValor1.Name = "tbValor1";
            this.tbValor1.Size = new System.Drawing.Size(100, 20);
            this.tbValor1.TabIndex = 9;
            // 
            // btCalcular
            // 
            this.btCalcular.Location = new System.Drawing.Point(52, 99);
            this.btCalcular.Name = "btCalcular";
            this.btCalcular.Size = new System.Drawing.Size(75, 23);
            this.btCalcular.TabIndex = 10;
            this.btCalcular.Text = "Calcular";
            this.btCalcular.UseVisualStyleBackColor = true;
            this.btCalcular.Click += new System.EventHandler(this.btCalcular_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(505, 300);
            this.Controls.Add(this.btCalcular);
            this.Controls.Add(this.tbValor1);
            this.Controls.Add(this.btNegar);
            this.Controls.Add(this.btSumar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btSumar;
        private System.Windows.Forms.Button btNegar;
        private System.Windows.Forms.TextBox tbValor1;
        private System.Windows.Forms.Button btCalcular;
    }
}

