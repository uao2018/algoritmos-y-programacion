﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraGrafica
{
    public partial class Form1 : Form
    {
        char operador;
        int valor1 = 0;
        int valor2 = 0;
        int resultado = 0;

        public Form1()        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)        {

        }

        private void btSumar_Click(object sender, EventArgs e)        {
            operador = '+';
            valor1 = int.Parse(tbValor1.Text);
            tbValor1.Clear();        
        }
        private void btCalcular_Click(object sender, EventArgs e)  {
            switch (operador) {
                case '+':
                    valor2 = int.Parse(tbValor1.Text);
                    resultado = Calculadora.sumar(valor1, valor2);
                    tbValor1.Text = resultado.ToString();
                    break;
                case '¬':
                    resultado = Calculadora.negar(valor1);
                    tbValor1.Text = resultado.ToString();
                    break;

            }

        }
        private void textBox1_TextChanged(object sender, EventArgs e)        {
        }

        private void btNegar_Click(object sender, EventArgs e)        {
            operador = '¬';
            valor1 = int.Parse(tbValor1.Text);
            tbValor1.Clear();
        }
    }
    class Calculadora
    {
        public static int sumar(int a, int b)
        {
            return a + b;
        }
        public static int negar(int valor)
        {
            return (-1 * valor);
        }

    }
}
