﻿namespace CalculadoraGraficaOpciones
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbValor1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbValor2 = new System.Windows.Forms.TextBox();
            this.tbResultados = new System.Windows.Forms.TextBox();
            this.btSumar = new System.Windows.Forms.Button();
            this.btRestar = new System.Windows.Forms.Button();
            this.btCoseno = new System.Windows.Forms.Button();
            this.btLimpiar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(249, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Valor1";
            // 
            // tbValor1
            // 
            this.tbValor1.Location = new System.Drawing.Point(366, 25);
            this.tbValor1.Name = "tbValor1";
            this.tbValor1.Size = new System.Drawing.Size(100, 20);
            this.tbValor1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(252, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Valor2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(255, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Resultado";
            // 
            // tbValor2
            // 
            this.tbValor2.Location = new System.Drawing.Point(366, 81);
            this.tbValor2.Name = "tbValor2";
            this.tbValor2.Size = new System.Drawing.Size(100, 20);
            this.tbValor2.TabIndex = 3;
            // 
            // tbResultados
            // 
            this.tbResultados.BackColor = System.Drawing.Color.GreenYellow;
            this.tbResultados.Location = new System.Drawing.Point(366, 133);
            this.tbResultados.Name = "tbResultados";
            this.tbResultados.Size = new System.Drawing.Size(100, 20);
            this.tbResultados.TabIndex = 5;
            // 
            // btSumar
            // 
            this.btSumar.Location = new System.Drawing.Point(26, 14);
            this.btSumar.Name = "btSumar";
            this.btSumar.Size = new System.Drawing.Size(28, 23);
            this.btSumar.TabIndex = 7;
            this.btSumar.Text = "+";
            this.btSumar.UseVisualStyleBackColor = true;
            this.btSumar.Click += new System.EventHandler(this.btSumar_Click);
            // 
            // btRestar
            // 
            this.btRestar.Location = new System.Drawing.Point(26, 43);
            this.btRestar.Name = "btRestar";
            this.btRestar.Size = new System.Drawing.Size(28, 23);
            this.btRestar.TabIndex = 8;
            this.btRestar.Text = "-";
            this.btRestar.UseVisualStyleBackColor = true;
            // 
            // btCoseno
            // 
            this.btCoseno.Location = new System.Drawing.Point(65, 14);
            this.btCoseno.Name = "btCoseno";
            this.btCoseno.Size = new System.Drawing.Size(43, 23);
            this.btCoseno.TabIndex = 9;
            this.btCoseno.Text = "Cos";
            this.btCoseno.UseVisualStyleBackColor = true;
            this.btCoseno.Click += new System.EventHandler(this.btCoseno_Click);
            // 
            // btLimpiar
            // 
            this.btLimpiar.Location = new System.Drawing.Point(65, 43);
            this.btLimpiar.Name = "btLimpiar";
            this.btLimpiar.Size = new System.Drawing.Size(43, 23);
            this.btLimpiar.TabIndex = 10;
            this.btLimpiar.Text = "CE";
            this.btLimpiar.UseVisualStyleBackColor = true;
            this.btLimpiar.Click += new System.EventHandler(this.btLimpiar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(503, 261);
            this.Controls.Add(this.btLimpiar);
            this.Controls.Add(this.btCoseno);
            this.Controls.Add(this.btRestar);
            this.Controls.Add(this.btSumar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbResultados);
            this.Controls.Add(this.tbValor2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbValor1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbValor1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbValor2;
        private System.Windows.Forms.TextBox tbResultados;
        private System.Windows.Forms.Button btSumar;
        private System.Windows.Forms.Button btRestar;
        private System.Windows.Forms.Button btCoseno;
        private System.Windows.Forms.Button btLimpiar;
    }
}

