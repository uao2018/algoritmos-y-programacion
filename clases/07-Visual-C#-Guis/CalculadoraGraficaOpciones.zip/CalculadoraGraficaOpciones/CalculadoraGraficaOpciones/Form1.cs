﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraGraficaOpciones {
    public partial class Form1 : Form     {
        public Form1() {
            InitializeComponent();
        }

        private void btSumar_Click(object sender, EventArgs e)        {
            double v1 = double.Parse(tbValor1.Text);
            double v2 = double.Parse(tbValor2.Text);
            double res = v1 + v2;
            tbResultados.Text = Convert.ToString(res);
        }

        private void btLimpiar_Click(object sender, EventArgs e)
        {
            tbValor1.Clear();
            tbValor2.Clear();
            tbResultados.Clear();
        }

        private void btCoseno_Click(object sender, EventArgs e)
        {
            double v1 = double.Parse(tbValor1.Text);
            double res = Math.Cos (v1);
            tbResultados.Text = Convert.ToString(res);

        }
    }
}
