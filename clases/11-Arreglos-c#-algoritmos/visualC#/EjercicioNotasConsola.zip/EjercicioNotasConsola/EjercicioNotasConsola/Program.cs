﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioNotasConsola
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Cuantas notas: ");
            int numNotas = Convert.ToInt32(Console.ReadLine());

            double[] arrNotas;
            arrNotas = new double[numNotas];

            Funciones.leerNotas(arrNotas);
            double prom = Funciones.calcularPromedio(arrNotas);
            int mayores = Funciones.calcularMayoresPromedio(arrNotas, prom);

            Console.WriteLine("" + prom + ",        " + mayores);
            Console.ReadKey();
            
        }
    }
}
