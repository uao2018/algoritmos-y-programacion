﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

namespace EjercicioNotasGrafica
{
    class Funciones    {
        public static void leerNotas(double[] arreglo)        {
            for (int i = 0; i < arreglo.Length; i++)            {
                Console.WriteLine(" Ingrese nota: ");
                double nota = Convert.ToDouble(Console.ReadLine());
                arreglo[i] = nota;
            }
        }

        public static void leerNotasGrafico (double[] arreglo)
        {
            for (int i = 0; i < arreglo.Length; i++)
            {
                string strNota = Interaction.InputBox (" Ingrese nota: ");
                double nota = Convert.ToDouble(strNota);
                arreglo[i] = nota;
            }
       }

        public static double calcularPromedio (double [] arreglo)   {
            double suma = 0;
            for (int i=0; i < arreglo.Length; i++)            {
                double nota = arreglo[i];
                suma = suma + nota;
            }
            return suma / arreglo.Length;
        }
        public static int calcularMayoresPromedio(double[] arreglo, double promedio)        {
            int contador = 0;
            for (int i = 0; i < arreglo.Length; i++)            {
                double nota = arreglo[i];
                if (nota > promedio)
                    contador++;
            }
            return contador;
        }
    }
}
