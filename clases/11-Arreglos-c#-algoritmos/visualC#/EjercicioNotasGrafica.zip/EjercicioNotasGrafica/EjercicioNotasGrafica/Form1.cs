﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace EjercicioNotasGrafica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btProcesar_Click(object sender, EventArgs e)
        {
            string strNotas = Interaction.InputBox("Ingrese Numero de Nota");
            int numNotas = Convert.ToInt32(strNotas);

            double[] arrNotas = new double[numNotas];
            Funciones.leerNotasGrafico (arrNotas);

            double prom = Funciones.calcularPromedio(arrNotas);
            int mayores = Funciones.calcularMayoresPromedio(arrNotas, prom);

            MessageBox.Show (" Resultado: " + prom + ",     " + mayores);
        
        }
    }
}
