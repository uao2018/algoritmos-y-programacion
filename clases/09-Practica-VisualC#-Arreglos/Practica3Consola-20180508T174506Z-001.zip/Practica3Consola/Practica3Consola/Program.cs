﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica3Consola{
    class Program    {
        static void Main(string[] args)        {
            int N;
            Console.Write("N: ");
            N = Convert.ToInt32(Console.ReadLine());
            string[] arrNombres = new string[N];
            double[] arrNotas = new double[N];

            llenarDatos(arrNombres, arrNotas);
            //redondearDatos(arrNotas);
            ordenarDatos(arrNombres, arrNotas);
            string cadenaReporte = reporteDatos(arrNombres, arrNotas);
            Console.WriteLine(cadenaReporte);
            Console.ReadKey();
        }
        // Llena los arreglos con nombres y notas
        static void llenarDatos(string[] arrNombres, double[] arrNotas) {
            int n = arrNombres.Length;
            for (int i=0; i < n; i++){
                Console.Write("Nombre: ");
                string nombre = Console.ReadLine();
                arrNombres[i] = nombre;

                Console.Write("Nota: ");
                double nota = Convert.ToDouble(Console.ReadLine());
                arrNotas[i] = nota;
            }
              


        }

        static string reporteDatos(string[] arrNombres, double[] arrNotas) {
            string cadenaReporte = "\n\n----REPORTE-----\n";
            cadenaReporte = cadenaReporte + "Nombre\t\tNota\n";
            int n = arrNombres.Length;
            for (int i=0; i < n; i++) {
                string nombre = arrNombres[i];
                double nota = arrNotas[i];
                string cad = nombre + "\t\t" + nota + "\n";
                cadenaReporte = cadenaReporte + cad;
            }
            return cadenaReporte;
        }

        static void ordenarDatos (string[] arrNombres, double[] arrNotas) {
          for (int a = 1; a < arrNombres.Length; a++)
                for (int b = arrNombres.Length - 1; b >= a; b--) {
                    if (arrNombres[b - 1].CompareTo (arrNombres[b]) > 0) {
                        string tmpNombre = arrNombres[b - 1];
                        arrNombres[b - 1] = arrNombres[b];
                        arrNombres[b] = tmpNombre;

                        double tmpNota = arrNotas[b - 1];
                        arrNotas[b - 1] = arrNotas[b];
                        arrNotas[b] = tmpNota;
                    }
                }
        }
    }
}
